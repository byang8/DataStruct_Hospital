package Priority_Queue;

public class Main {

	public static void main(String[] args) {
		// Main Queue code will go here. 
	}

}
